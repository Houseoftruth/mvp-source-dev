var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'shinedesign',
applicationName: 'lamb',
appUid: 'WNp8FMV7rdSsyk5lxl',
orgUid: 'kRgjJDrLtqvhG5vtGM',
deploymentUid: 'ec323b61-b2fc-4b7a-a6b1-7145481363e7',
serviceName: 'lamb',
stageName: 'prod',
pluginVersion: '3.3.0'})
const handlerWrapperArgs = { functionName: 'lamb-prod-hello', timeout: 10}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
