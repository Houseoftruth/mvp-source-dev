var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'shinedesign',
applicationName: 'lamb',
appUid: 'WNp8FMV7rdSsyk5lxl',
orgUid: 'kRgjJDrLtqvhG5vtGM',
deploymentUid: '1c0392e4-1db3-43ea-92b5-86d624e844e6',
serviceName: 'lamb',
stageName: 'prod',
pluginVersion: '3.3.0'})
const handlerWrapperArgs = { functionName: 'lamb-prod-hello', timeout: 10}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
