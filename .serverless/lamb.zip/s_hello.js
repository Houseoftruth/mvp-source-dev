var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'shinedesign',
applicationName: 'lamb',
appUid: 'WNp8FMV7rdSsyk5lxl',
orgUid: 'kRgjJDrLtqvhG5vtGM',
deploymentUid: 'd5fd11c2-7a19-4ee1-949a-c4313ab32e03',
serviceName: 'lamb',
stageName: 'dev',
pluginVersion: '3.3.0'})
const handlerWrapperArgs = { functionName: 'lamb-dev-hello', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
