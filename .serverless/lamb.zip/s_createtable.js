var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'shinedesign',
applicationName: 'lamb',
appUid: 'WNp8FMV7rdSsyk5lxl',
orgUid: 'kRgjJDrLtqvhG5vtGM',
deploymentUid: 'a551bd02-16cc-46b0-bf8c-c956b44aaea7',
serviceName: 'lamb',
stageName: 'prod',
pluginVersion: '3.3.0'})
const handlerWrapperArgs = { functionName: 'lamb-prod-createtable', timeout: 10}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.createTable, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
