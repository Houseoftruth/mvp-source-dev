var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'shinedesign',
applicationName: 'lamb',
appUid: 'WNp8FMV7rdSsyk5lxl',
orgUid: 'kRgjJDrLtqvhG5vtGM',
deploymentUid: '3f7a0d64-6643-4e3d-9a66-0ce17eb18650',
serviceName: 'lamb',
stageName: 'prod',
pluginVersion: '3.3.0'})
const handlerWrapperArgs = { functionName: 'lamb-prod-storeqr', timeout: 10}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.saveFileToS3, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
